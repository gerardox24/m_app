package pe.edu.upc.iceandfire.controllers.adapters

import pe.edu.upc.iceandfire.models.Quote
import androidx.recyclerview.widget.RecyclerView

class QuoteAdapter(var quote: Quote) : RecyclerView.Adapter<QuoteAdapter.ViewHolder>() {

}