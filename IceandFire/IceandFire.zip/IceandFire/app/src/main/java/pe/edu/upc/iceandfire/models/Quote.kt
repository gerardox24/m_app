package pe.edu.upc.iceandfire.models

data class Quote (
    val quote: String,
    val character: String
)