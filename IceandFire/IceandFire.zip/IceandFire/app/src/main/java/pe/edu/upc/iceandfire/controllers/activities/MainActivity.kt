package pe.edu.upc.iceandfire.controllers.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import pe.edu.upc.iceandfire.R
import pe.edu.upc.iceandfire.network.GOTQuotesAPI

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        GOTQuotesAPI.requestGetQuotes({
            response -> check = response
            Log.d('IceandfireApp',response!!.quote)
        },{
            error -> Log.d("IceandfireApp",error!!.message)
        })
    }
}
