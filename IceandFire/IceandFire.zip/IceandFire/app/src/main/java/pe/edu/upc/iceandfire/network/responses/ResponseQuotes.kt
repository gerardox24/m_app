package pe.edu.upc.iceandfire.network.responses

class ResponseQuotes (
    val quote : String,
    val character: String
) {
    constructor() : this("","")
}